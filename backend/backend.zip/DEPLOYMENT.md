# Deployment Instructions for cPanel

## Prerequisites
- Python 3.12 virtual environment created in cPanel
- SSH access to the server

## Step 1: Upload Files
Upload all backend files to: `/home/loopzmpp/antibiotics.loopdimension.com/`

## Step 2: Install Dependencies
```bash
cd /home/loopzmpp/antibiotics.loopdimension.com
source /home/loopzmpp/virtualenv/antibiotics.loopdimension.com/3.12/bin/activate
pip install -r requirements.txt
```

## Step 3: Run Migrations
```bash
python manage.py migrate
```

## Step 4: Create Superuser
```bash
python manage.py shell -c "from django.contrib.auth.models import User; from rest_framework.authtoken.models import Token; u = User.objects.create_user('orange', password='00oo00oo'); u.is_superuser = True; u.is_staff = True; u.save(); token = Token.objects.create(user=u); print(f'Token: {token.key}')"
```

## Step 5: Import Data
```bash
python import_all_data.py
```

## Step 6: Collect Static Files
```bash
python manage.py collectstatic --noinput
```

## Step 7: Set Environment Variable (Optional)
In cPanel, add environment variable:
- Name: `DEBUG`
- Value: `False` (for production)

## Step 8: Restart Application
In cPanel Python App section, click "Restart"

## Database Location
SQLite database: `/home/loopzmpp/antibiotics.loopdimension.com/db.sqlite3`

## Important Files
- `.htaccess` - Apache/Passenger configuration
- `passenger_wsgi.py` - WSGI entry point
- `requirements.txt` - Python dependencies
- `db.sqlite3` - SQLite database (auto-created)

## Troubleshooting
1. Check error logs in cPanel
2. Verify virtual environment path in .htaccess
3. Ensure all dependencies are installed
4. Check file permissions (755 for directories, 644 for files)

## API Endpoints
- Login: https://antibiotics.loopdimension.com/api/auth/login/
- Patients: https://antibiotics.loopdimension.com/api/patients/
- Analysis: https://antibiotics.loopdimension.com/api/patients/prescription_analysis/
